import { Plugin, Notice, TFile, MarkdownRenderChild, WorkspaceLeaf } from 'obsidian';
import { LLMService } from './llm/LLMService';
import { OutlookService } from './outlook/OutlookService';
import { TemplateManager } from './notes/TemplateManager';
import { DailyService } from './daily/DailyService';
import { TeamService } from './team/TeamService';
import { MonitoringSettingTab, DEFAULT_SETTINGS, MonitoringPluginSettings } from './settings/SettingsTab';
import { ChatView, CHAT_VIEW_TYPE } from './chat/ChatView';
import { MainPageView, MAIN_PAGE_VIEW_TYPE } from './main-page/MainPageView';
import { TagModal } from './modals/TagModal';
import { ResourceModal } from './modals/ResourceModal';
import { NewTaskModal } from './modals/NewTaskModal';
import { ResponsibleButtonModal } from './modals/ResponsibleButtonModal';
import { MonitoringDurationChild } from './MonitoringDurationChild';

export default class MonitoringPlugin extends Plugin {
    settings: MonitoringPluginSettings;
    llmService: LLMService;
    outlookService: OutlookService;
    templateManager: TemplateManager;
    dailyService: DailyService;

    async onload() {
        await this.loadSettings();

        // Initialize the submodules
        this.llmService = new LLMService(this.settings);
        this.outlookService = new OutlookService(this.settings, this.app);
        this.templateManager = new TemplateManager(this.app, this.settings);
        this.dailyService = new DailyService(this.app, this.settings);

        // Register Chat View
        this.registerView(
            CHAT_VIEW_TYPE,
            (leaf) => new ChatView(leaf, this.llmService)
        );

        this.registerView(
            MAIN_PAGE_VIEW_TYPE,
            (leaf) => new MainPageView(leaf, this)
        );

        // Ribbon icons
        this.addRibbonIcon('mail', 'Импортировать почту', async () => {
            await this.processEmails();
        });

        this.addRibbonIcon('message-square', 'Корпоративный ИИ Чат', async () => {
            await this.activateChatView();
        });

        this.addRibbonIcon('brain', 'Главная панель проектов', async () => {
            await this.activateMainPageView();
        });

        // Commands
        this.addCommand({
            id: 'import-mail',
            name: 'Обновить почту (Import Mail)',
            callback: async () => {
                await this.processEmails();
            }
        });

        this.addCommand({
            id: 'open-ai-chat',
            name: 'Открыть корпоративный чат (Open AI Chat)',
            callback: async () => {
                await this.activateChatView();
            }
        });

        // Register custom markdown blocks
        this.registerMarkdownCodeBlockProcessor("monitoring-ui", (source, el, ctx) => {
            const container = el.createDiv({ cls: 'monitoring-dashboard-ui' });
            container.createEl('h4', { text: 'Управление отслеживанием' });
            const wrapper = container.createDiv({ cls: 'monitoring-input-wrapper' });
            
            const input = wrapper.createEl('input', { 
                type: 'text', 
                placeholder: 'Введите ключевые слова темы...',
                cls: 'monitoring-topic-input'
            });
            const btn = wrapper.createEl('button', { text: 'Добавить', cls: 'monitoring-add-btn' });
            
            btn.onclick = async () => {
                const topic = input.value.trim();
                if (!topic) return;
                
                const dashboardFile = this.app.vault.getAbstractFileByPath(this.settings.dashboardNoteName) as TFile;
                if (dashboardFile) {
                    await this.app.fileManager.processFrontMatter(dashboardFile, (fm) => {
                        if (!fm['tracked_subjects']) fm['tracked_subjects'] = [];
                        if (!Array.isArray(fm['tracked_subjects'])) fm['tracked_subjects'] = [fm['tracked_subjects']];
                        if (!fm['tracked_subjects'].includes(topic)) fm['tracked_subjects'].push(topic);
                    });
                    new Notice(`Тема "${topic}" добавлена!`);
                    input.value = '';
                } else {
                    new Notice('Файл дашборда не найден!');
                }
            };
        });

        this.registerMarkdownCodeBlockProcessor("monitoring-duration", (source, el, ctx) => {
            const file = this.app.vault.getAbstractFileByPath(ctx.sourcePath);
            if (!(file instanceof TFile)) return;

            const child = new MonitoringDurationChild(el, this, file);
            ctx.addChild(child);
        });

        this.addSettingTab(new MonitoringSettingTab(this.app, this));
    }

    async activateChatView() {
        const { workspace } = this.app;
        let leaf: WorkspaceLeaf | null = workspace.getLeavesOfType(CHAT_VIEW_TYPE)[0];
        if (!leaf) {
            leaf = workspace.getRightLeaf(false);
            if (leaf) await leaf.setViewState({ type: CHAT_VIEW_TYPE, active: true });
        }
        if (leaf) workspace.revealLeaf(leaf);
    }

    async activateMainPageView() {
        const { workspace } = this.app;
        let leaf: WorkspaceLeaf | null = workspace.getLeavesOfType(MAIN_PAGE_VIEW_TYPE)[0];
        if (!leaf) {
            leaf = workspace.getLeaf(true);
            await leaf.setViewState({ type: MAIN_PAGE_VIEW_TYPE, active: true });
        }
        if (leaf) workspace.revealLeaf(leaf);
    }

    async processEmails() {
        new Notice('Запуск сканирования почты...');
        try {
            const allEmails = await this.outlookService.fetchEmails();
            allEmails.reverse(); 
            let newEmails = allEmails.filter(e => !this.settings.scannedEmailIds.includes(e.entryId));
            if (newEmails.length === 0) newEmails = allEmails.slice(Math.max(allEmails.length - 10, 0));
            if (newEmails.length === 0) { new Notice('Папка пуста.'); return; }

            const dashboardFile = this.app.vault.getAbstractFileByPath(this.settings.dashboardNoteName) as TFile;
            let trackedSubjects: string[] = [];
            if (dashboardFile) {
                const cache = this.app.metadataCache.getFileCache(dashboardFile);
                if (cache?.frontmatter?.['tracked_subjects']) {
                    trackedSubjects = cache.frontmatter['tracked_subjects'].map((s: string) => s.toLowerCase());
                }
            }

            let processedCount = 0;
            for (const email of newEmails) {
                if (trackedSubjects.length > 0) {
                    const topicLower = email.conversationTopic.toLowerCase();
                    if (!trackedSubjects.some(ts => topicLower.includes(ts))) continue;
                }
                const existingNote = await this.templateManager.getIncidentNoteByTopic(email.conversationTopic);
                if (existingNote) {
                    const content = await this.templateManager.readNoteContent(existingNote);
                    const match = content.match(/## Текущее саммари инцидента\n([\s\S]*?)\n---/m);
                    const oldSummary = match ? match[1].trim() : 'Логов нет.';
                    const combinedSummary = await this.llmService.updateIncidentSummary(oldSummary, email.bodyPreview);
                    await this.templateManager.updateIncidentNote(existingNote, email, combinedSummary);
                } else {
                    const summary = await this.llmService.summarizeIncident(email.bodyPreview);
                    await this.templateManager.createIncidentNote(email, summary);
                }
                processedCount++;
                if (!this.settings.scannedEmailIds.includes(email.entryId)) this.settings.scannedEmailIds.push(email.entryId);
            }
            await this.saveSettings();
            new Notice(processedCount === 0 ? 'Нет писем по отслеживаемым темам.' : `Готово! Обработано писем: ${processedCount}`);
        } catch (error) {
            console.error(error);
            new Notice('Ошибка при импорте: ' + error.message);
        }
    }

    onunload() {}

    async loadSettings() {
        this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
    }

    async saveSettings() {
        await this.saveData(this.settings);
        this.llmService.updateSettings(this.settings);
        this.outlookService.updateSettings(this.settings);
        this.templateManager.updateSettings(this.settings);
    }

    async addResourceToNote(file: TFile, link: string, description: string) {
        const content = await this.app.vault.read(file);
        const header = "## 🔗 База материалов и ресурсов";
        const normalizedLink = link.startsWith('http') ? `[Открыть](${link})` : `[Открыть](file:///${link.replace(/\\/g, '/')})`;
        const newRow = `| ${normalizedLink} | ${description || link} |\n`;
        let newContent = content.includes(header) ? content.replace(header, `${header}\n${newRow}`) : content + `\n\n${header}\n| Ресурс | Описание |\n| --- | --- |\n${newRow}`;
        await this.app.vault.modify(file, newContent);
    }

    async addTagToNote(file: TFile, tag: string) {
        await this.app.fileManager.processFrontMatter(file, (fm) => {
            let tags = fm['tags'] || [];
            if (typeof tags === 'string') tags = tags.split(',').map(t => t.trim());
            if (!Array.isArray(tags)) tags = [tags];
            const cleanTag = tag.startsWith('#') ? tag.substring(1) : tag;
            if (!tags.includes(cleanTag)) {
                tags.push(cleanTag);
                fm['tags'] = tags;
            }
        });
    }

    async removeTagFromNote(file: TFile, tag: string) {
        await this.app.fileManager.processFrontMatter(file, (fm) => {
            let tags = fm['tags'] || [];
            if (typeof tags === 'string') tags = tags.split(',').map(t => t.trim());
            if (!Array.isArray(tags)) tags = [tags];
            const cleanTag = tag.startsWith('#') ? tag.substring(1) : tag;
            fm['tags'] = tags.filter((t: string) => t !== cleanTag);
        });
    }

    async moveFileToFolder(file: TFile, folderName: string) {
        try {
            if (!this.app.vault.getAbstractFileByPath(folderName)) await this.app.vault.createFolder(folderName);
            const newPath = `${folderName}/${file.name}`;
            if (this.app.vault.getAbstractFileByPath(newPath)) { new Notice(`Файл уже существует в "${folderName}"`); return; }
            await this.app.fileManager.renameFile(file, newPath);
            new Notice(`Заметка перемещена в "${folderName}"`);
        } catch (e) {
            console.error(e);
            new Notice(`Ошибка при перемещении: ${e.message}`);
        }
    }
}
